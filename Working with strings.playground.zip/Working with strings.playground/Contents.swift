import UIKit
import Foundation

////Задание 1
func nextNumber(_ number: Int) -> Int {
    return number + 1
}
nextNumber(1)

//Задание 2
func oneNumber(_ number: Int) -> Int {
    let value = number * number
    return value
}
oneNumber(3)

//Задание 3
func timeNumber(_ seconds: Int) -> (minutes: Int, seconds: Int) {
    let minutes = seconds / 60
    let seconds = seconds % 60
    return (minutes, seconds)
}
timeNumber(70)

//Задание 4
func concatenate() -> String {
    let string1 =  "Writing Swift code "
    let string2 = "is interactive and fun"
    return string1 + string2
}
concatenate()

//Задание 5
func dataTime(datе: String) -> Date? {
    let formatter = DateFormatter()
    formatter.dateFormat = "yyyy-MM-dd"
    let date: Date = Date()
    formatter.string(from: date)
    return formatter.date(from: datе) ?? Date()
}
dataTime(datе: "2002-08-21")
