import UIKit
import Foundation


//Задание 1
let days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
let numberDays = ["Первый день недели","Второй день недели","Третий день недели","Четвертый день недели","Пятый день недели","Шестой день недели","Седьмой день недели"]
var dict = Dictionary(uniqueKeysWithValues: zip(days, numberDays))
print(dict)
dict["Sunday"]

//Задание 2
let days2 = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
let numberDays2 = [1, 2, 3, 4, 5, 6, 7]
var dict2 = Dictionary(uniqueKeysWithValues: zip(days2, numberDays2))
for (days2, numberDays2) in dict2 {
    print ("\(days2) - \(numberDays2)")
}

//Задание 3
var dataBase = [String:String]()
dataBase["Alex"] = "12345"
dataBase["Mark"] = "jz100"
dataBase["bmw"] = "m5competion"
print(dataBase)

//Задание 4
enum CustomError: Error, LocalizedError {
    case invalidPassword
    case userNotFound
    case invalidUsername(Character)

    public var errorDescription: String? {
        switch self {
        case .invalidPassword:
            return "Неправильный пароль"
        case .userNotFound:
            return "Пользователь не найден"
        case let .invalidUsername(char):
            return "Некорректный символ в имени пользователя - \(char)"
        }
    }
}

//Задание 5
func validate(name: String, password: String) throws {
    for character in name {
        guard character.isLetter else {
            throw CustomError.invalidUsername(character)
    }
    guard dataBase[name] == password else {
        throw CustomError.invalidPassword
    }
    guard dataBase[name] != nil else {
        throw CustomError.userNotFound
    }
    }
}

//Задание 6
func errorHandling(name: String, password: String) {
do {
    try validate(name: name, password: password)
    print("Вход в систему успешно осуществлён")
    } catch {
        print(error.localizedDescription)
    }
}

func errorHandlingTry(name: String, password: String) {
    print((try? validate(name: name, password: password)) == nil)
}
errorHandlingTry(name: "Alex", password: "12345")
