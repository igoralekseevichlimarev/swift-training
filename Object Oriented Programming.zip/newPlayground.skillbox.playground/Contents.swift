import UIKit

//Задание 1, 2, 3
class Animal {
    var energy: Int
    var theWeight: Int
    var currentAge: Int
    var maximumAge: Int
    var name: String
    
    init(energy: Int, theWeight: Int, currentAge: Int, maximumAge: Int, name: String) {
        self.energy = energy
        self.theWeight = theWeight
        self.currentAge = currentAge
        self.maximumAge = maximumAge
        self.name = name
    }
    
    var isTooOld: Bool { self.currentAge >= self.maximumAge }
    
//Задание 4, 5, 6
    func dream () {
        self.energy += 5
        self.currentAge += 1
        print("\(self.name) спит")
    }
    
    func food () {
        self.energy += 3
        self.theWeight += 1
        self.currentAge += 1
        print("\(self.name) есть")
    }
    
    func movement() {
        self.energy -= 5
        self.theWeight -= 1
        self.currentAge += 1
        print("\(self.name) передвигается")
    }
    
    func tryIncrementAge  () {
        if (Bool.random()) {
            self.currentAge += 1
        } else if self.currentAge >= maximumAge || self.theWeight == 0 || self.energy == 0 {
            self.currentAge
        }
    }
    func create() -> Animal {
        let newBabyAnimal = Animal(energy: Int.random(in: 1...10), theWeight: Int.random(in: 1...5), currentAge: 0, maximumAge: self.maximumAge, name: self.name)
        print("Был рожден новый представитель \(name), энергия \(newBabyAnimal.energy), вес \(newBabyAnimal.theWeight), максимальная продолжительность жизни \(maximumAge).")
        return newBabyAnimal
    }
}

//Задание 7, 8, 9
class Bird: Animal {
    override func movement() {
        super.movement()
        print("\(self.name) - летит")
    }
    override func create() -> Bird {
        let newBabyBird = Bird(energy: Int.random(in: 1...10), theWeight: Int.random(in: 1...5), currentAge: 0, maximumAge: self.maximumAge, name: self.name)
        print("Был рожден новый представитель \(name), энергия \(newBabyBird.energy), вес \(newBabyBird.theWeight), максимальная продолжительность жизни \(maximumAge).")
        return newBabyBird
    }
}

class Fish: Animal {
    override func movement() {
        super.movement()
        print("\(self.name) - плывет")
    }
    override func create() -> Fish {
        let newBabyFish = Fish(energy: Int.random(in: 1...10), theWeight: Int.random(in: 1...5), currentAge: 0, maximumAge: self.maximumAge, name: self.name)
        print("Был рожден новый представитель \(name), энергия \(newBabyFish.energy), вес \(newBabyFish.theWeight), максимальная продолжительность жизни \(maximumAge).")
        return newBabyFish
    }
}
class Dog: Animal {
    override func movement() {
        super.movement()
        print("\(self.name) - бежит")
    }
    override func create() -> Dog {
        let newBabyDog = Dog(energy: Int.random(in: 1...10), theWeight: Int.random(in: 1...5), currentAge: 0, maximumAge: self.maximumAge, name: self.name)
        print("Был рожден новый представитель \(name), энергия \(newBabyDog.energy), вес \(newBabyDog.theWeight), максимальная продолжительность жизни \(maximumAge).")
        return newBabyDog
    }
}
// Задания №10, 11, 12

class NatureReserve {
    var animalZoo: Array<Animal>
    
    
    init(animalZoo: Array<Animal>) {
        self.animalZoo = animalZoo
        
    }
    
    
    
    func lifeZoo() {
        
        for _ in 0...20 {
            
            for animal in animalZoo {
                
                switch Int.random(in: 1...4) {
                case 1:
                    animal.dream()
                case 2:
                    animal.food()
                case 3:
                    animal.movement()
                case 4:
                    animalZoo.append(animal.create())
                    
                default:
                    break
                }
            }
            animalZoo.removeAll(where: {$0.isTooOld == true})
            
        }
        
        if animalZoo.isEmpty {
            print("Зоопарк пуст")
        } else {
            print("В зоопарке \(animalZoo.count) животных.")
        }
        
    }
}



let bird1 = Bird(energy: 10, theWeight: 20, currentAge: 1, maximumAge: 3, name: "bird1")
let bird2 = Bird(energy: 34, theWeight: 42, currentAge: 2, maximumAge: 4, name: "bird2")
let bird3 = Bird(energy: 2, theWeight: 10, currentAge: 4, maximumAge: 4, name: "bird3")
let bird4 = Bird(energy: 2, theWeight: 3, currentAge: 4, maximumAge: 5, name: "bird4")
let bird5 = Bird(energy: 1, theWeight: 2, currentAge: 3, maximumAge: 4, name: "bird5")


let fish1 = Fish(energy: 4, theWeight: 10, currentAge: 10, maximumAge: 11, name: "fish1")
let fish2 = Fish(energy: 14, theWeight: 14, currentAge: 13, maximumAge: 12, name: "fish2")
let fish3 = Fish(energy: 14, theWeight: 12, currentAge: 12, maximumAge: 35, name: "fish3")


let dog1 = Dog(energy: 54, theWeight: 32, currentAge: 35, maximumAge: 13, name: "dog1")
let dog2 = Dog(energy: 45, theWeight: 44, currentAge: 45, maximumAge: 43, name: "dog2")


let animal1 = Animal(energy: 35, theWeight: 23, currentAge: 32, maximumAge: 23, name: "Lion")
let animal2 = Animal(energy: 35, theWeight: 35, currentAge: 43, maximumAge: 34, name: "Wolf")
let animal3 = Animal(energy: 55, theWeight: 54, currentAge: 45, maximumAge: 45, name: "Tigr")

var classReserve = NatureReserve(animalZoo: [bird1, bird2, bird3, bird4, bird5, fish1, fish2, fish3, dog1, dog2, animal1, animal2, animal3])
classReserve.lifeZoo()
