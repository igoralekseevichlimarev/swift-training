//
//  Constants.swift
//  Module11Skillbox
//
//  Created by Лимарев Игорь Алексеевич on 17.01.2023.
//

import Foundation

enum ConstantStrings {
    static let calculatorTitle = "Calculate"
}
