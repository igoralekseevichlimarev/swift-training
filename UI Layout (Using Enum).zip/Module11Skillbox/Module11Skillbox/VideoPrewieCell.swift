//
//  VideoPrewieCell.swift
//  Module11Skillbox
//
//  Created by Лимарев Игорь Алексеевич on 16.01.2023.
//

import UIKit

class VideoPrewieCell: UITableViewCell {
    @IBOutlet weak var videoImage: UIImageView!
}
