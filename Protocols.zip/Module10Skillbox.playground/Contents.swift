import UIKit

// Задание 1
protocol CalorieCountProtocol {
    var colories: Int { get }
    func description() -> String
}

struct CalorieStruct: CalorieCountProtocol {
    var colories: Int
    func description() -> String {
        return "Small"
    }
}
let caloriesStruct = CalorieStruct(colories: 1)
print(caloriesStruct)
caloriesStruct.description()

class ClassColories: CalorieCountProtocol {
    var colories: Int
    init(colories: Int) {
        self.colories = colories
    }
    func description() -> String {
        return "Many"
    }
}
let caloriesClass = ClassColories(colories: 2)
print(caloriesClass)
caloriesClass.description()

enum EnumColories: CalorieCountProtocol {
    case food
    var colories: Int {
        switch self {
        case .food : return 3
        }
    }
    func description() -> String {
        return "Soso"
    }
}
let enumColories = EnumColories.food
enumColories.colories
enumColories.description()

// Задание 2
enum BalanceType: Equatable {
    case positive, negative, neutral
}

struct Balance: Equatable {
    let type: BalanceType
    let amount: Int
}
let struct1Balance = Balance(type: .positive, amount: 1)
let struct2Balance = Balance(type: .negative, amount: -1)
struct1Balance==struct2Balance

class BalanceObject: Equatable {
    var amount: Int = 0
    init (amount: Int) {
        self.amount = amount
    }
    static func == (lhs: BalanceObject, rhs: BalanceObject) -> Bool {
        return lhs.amount == rhs.amount
    }
}
let class1Balance = BalanceObject(amount: 2)
let class2Balance = BalanceObject(amount: 2)
class1Balance==class2Balance

// Задание 3
protocol Dog {
    var name: String { get set }
    var color: String { get set }
}

struct Haski: Dog {
    var name: String
    var color: String
}

class Corgi: Dog {
    var name: String
    var color: String
    init (name: String, color: String) {
        self.name = name
        self.color = color
    }
}

struct Hound: Dog {
    var name: String
    var color: String
}
 
extension Dog {
    func speak() -> String {
        return "Gav"
    }
}

let someArray: [Dog] = [Haski(name: "Haski", color: "White"), Corgi(name: "Corgi", color: "Orange"), Hound(name: "Hound", color: "Brown")]
someArray.map({print($0.speak())})
    
    
    
    
    
    
    
    
