import UIKit
import Foundation

//Задание 1
func sumFirstSecondElement(_ array: [Int]) -> Int {
switch array.count {
case 0:
    return 0
case 1:
    return array[0]
default:
    break
    }
return array[0] + array[1]
}
sumFirstSecondElement([1])


//Задание 2
func arrayOne(_ array: [Int]) -> [Int]? {
    guard array.count < 2 else { return nil }
    return [array[0], (array.last ?? 0)]
}
arrayOne([1])

//Задание 3
let n = 5
var dates = [Date]()
for _ in 0 ..< n {
    dates.append(Date(timeIntervalSinceNow: TimeInterval(Int.random(in: -1000000000 ... 1000000000))))
}

var dateString = [String]()
for date in dates {
    let formatter = DateFormatter()
    formatter.dateFormat = "yyyy-MM-dd:mm:ss"
    let someDates = formatter.string(from: date)
    dateString.append(someDates)
    print(someDates)
}

//Задание 4
let m = 5
var dates2 = [Date]()
for _ in 0 ..< m {
    dates2.append(Date(timeIntervalSinceNow: TimeInterval(Int.random(in: -1000000000 ... 1000000000))))
}
func arrayDate(_ date: [Date]) -> [String] {
    let formatter = DateFormatter()
    formatter.dateFormat = "yyyy-MM-dd:mm:ss"
    let dateString2 = date.map {formatter.string(from: $0)}
    return dateString2
}
arrayDate([])

//Задание 5
var fruits:Set = ["orange", "apple", "banana", "grapefruit"]
var redFood:Set = ["apple", "tomato", "grapefruit", "strawberry"]
redFood.intersection(fruits)
fruits.symmetricDifference(redFood)
fruits.union(redFood)
fruits.subtract(redFood)

//Задание 6
func dublicateName(_ names: [String]) -> [String] {
    return Array(Set(names))
}
dublicateName(["Jora", "Karl", "Steven", "Alex", "Karl", "Steven"])
