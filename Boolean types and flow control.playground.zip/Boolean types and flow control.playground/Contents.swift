import UIKit
import Darwin

//Задание 1
func otherNumber(_ number1: Int, _ number2: Int) -> Bool {
    if number1 == number2 {
        print("равно")
    } else if number1 > number2 {
        print("больше")
    } else if number1 < number2 {
        print("меньше")
    }
    return number1 == number2
}
otherNumber(1, 2)

//Задание 2
func integerNumber(_ values: String?) -> Int {
    guard let number = Int(values ?? "") else {print("Ошибка")
        return -1
    }
    if (1...100).contains(number) {
        print("\(number) вне диапазона")
    } else {
    }
    return number
}
integerNumber("1")

//Задание 3
func bigElement() -> Int {
    let findLargestNum: [Int] = [1000, 1001, 857, 1]
    var maxNumber = 0
    for number in findLargestNum {
        if maxNumber < number {
            maxNumber = number
                }
            }
return maxNumber
}
bigElement()


//Задание 4
func valueProcessing(_ value: Int) {
switch value {
    case 1...3: print("проигрыш")
    case 4...6: print("победа")
    case 7...: print("У кубика только 6 граней!")
default: break
    }
}
valueProcessing(5)
