import UIKit

//Задание 1
//struct Person {
//    var name: String
//    var age: Int
//
//    func getAgeComparisonString(_ p: Person) -> String {
//        if p.age < age {
//            return ("\(p1.name) младше меня")
//        } else if p.age > age {
//            return ("\(p2.name) старше меня")
//        } else { p.age == age
//            return ("\(p3.name) такого же возраста, как и я")
//        }
//    }
//}
//var p1 = Person(name: "Антон", age: 24)
//var p2 = Person(name: "Андрей", age: 36)
//var p3 = Person(name: "Ольга", age: 24)
//
//p1.getAgeComparisonString(p2)
//p2.getAgeComparisonString(p1)
//p1.getAgeComparisonString(p3)

//Задание 2
struct Person {
    var name: String
    var age: Int
    lazy var person: String = {
        if self.age >= 5 && self.age <= 20 {
            return ("\(self.name), \(self.age) лет")
        } else {
            switch self.age % 10 {
        case 2...4: return ("\(self.name), \(self.age) года")
        case 4...: return ("\(self.name), \(self.age) лет")
        default: return ("\(self.name), \(self.age) года")
            }
        }
    }()
}
var p1 = Person(name: "Антон", age: 24)
var p2 = Person(name: "Андрей", age: 36)
var p3 = Person(name: "Ольга", age: 24)

print(p1.person)
print(p2.person)
print(p3.person)

//Задание 3, 4, 5
class Hero {
    private var lifeCount: Int
    init(lifeCount: Int) {
        self.lifeCount = lifeCount
    }
    
    func hit() {
        self.lifeCount -= 1
        print("Количество жизней \(lifeCount)")
    }
    
    func isLive() -> Bool {
        if self.lifeCount > 0 {return true}
        return false
    }
}
var heroClass = Hero(lifeCount: 5)
heroClass.hit()
heroClass.isLive()

//Задание 6
class SuperHero: Hero {
    override func hit() {
         
    }
}
var superhero1 = SuperHero(lifeCount: 2)
superhero1.hit()
superhero1.isLive()
